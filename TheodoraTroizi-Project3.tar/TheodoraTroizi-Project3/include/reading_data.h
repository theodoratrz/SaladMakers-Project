#include <stdio.h>
#include <time.h>
#include <sys/time.h> 
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

// function that reads from a file and prints the results
void reading_data();